#1. Write a function to add integer values of an array
def sum_array(a):
    b=0
    for i in a:
        if isinstance(i,int):
            b +=i
    return b
c=[1,2,3,'4',5,'6',7,8,'9']
d=sum_array(c)
print(f"the sum of integers in array is",d)




#2. Write a function to calculate the average value of an array of integers
def average_array(a):
    b=0
    c=0
    for i in a:
        if isinstance(i,int):
            b +=i
            c+=1
    if c==0:
        return 0
    else:
        return b/c
d=[1,2,3,'4',5,'6',7,8,'9']
e=average_array(d)
print(f"the average of integers in array is",e)



#3. Write a program to find the index of an array element
def index(a,b):
    for index,value in enumerate(a):
        if value==b:
            return index
    return-1
c=[1,2,3,4,5,6,7,8,9]
find=5
d=index(c,find)
if d != -1:
    print(f"index of",find, "in array is",d)
else:
    print(f"the entered num is not present in array")



#4. Write a function to test if array contains a specific value
def value(a,b):
    return b in a
c=[1,2,3,4,5]
d=4
if value(c,d):
    print(f"the array contains the value",d)
else:
    print(f"the array does not contain the value",d)



#5. Write a function to remove a specific element from an array
def remove(a,b):
    return[x for x in a if x!=b]
c=[1,2,3,4,5]
d=3
e=remove(c,d)
if e!=c:
    print(f"the element",d,"is removed",e)
else:
    print(f"the element",d,"is not present in array",e)



#6. Write a function to copy an array to another array
a=[1,2,3,4,5]
b=list(a)
print(a)
print(b)



#7. Write a function to insert an element at a specific position in the array
def insert_an_element(a,b,c):
    a.insert(c,b)
    return a
d=[1,2,3,5,6]
e=4
f=3
g=insert_an_element(d,e,f)
print(f"the element",e,"is inserted",g)


#8. Write a function to find the minimum and maximum value of an array
a=[12,44,63,34,54]
b=min(a)
c=max(a)
print("the maximum number is",c)
print("the minimum number is",b)



#9. Write a function to reverse an array of integer values
a=[1, 2, 3, 4, 5]
print (a[::-1])


#10. Write a function to find the duplicate values of an array
a = [1, 2, 3, 4, 2, 5, 3, 6, 7, 7, 2]
b = list(set([x for x in a if a.count(x) > 1]))
print("Duplicate values:", b)



#11. Write a program to find the common values between two arrays
def find_common_values(a, b):
    set1 = set(a)
    set2 = set(b)
    c = set1.intersection(set2)
    return list(c)
array1 = [1, 2, 3, 4, 5]
array2 = [3, 4, 5, 6, 7]

c = find_common_values(array1, array2)
print("Common values:", c)



#12. Write a method to remove duplicate elements from an array
def remove_duplicates(a):
    if not a:
        return a
    a.sort()
    index = 1
    for i in range(1, len(a)):
        if a[i] != a[i - 1]:
            a[index] = a[i]
            index += 1
    return a[:index]
b = [3, 1, 2, 2, 1, 4, 5, 4]
c = remove_duplicates(b)
print("Original Array:", b)
print("Array with Duplicates Removed:", c)




#13. Write a method to find the second largest number in an array
def find_second_largest(a):
    if len(a) < 2:
        return "Array should have at least two elements"
    a.sort(reverse=True)
    return a[1]
array = [3, 1, 8, 7, 5, 9]
result = find_second_largest(array)
print("Array:", array)
print("Second Largest Number:", result)




#15. Write a method to find number of even number and odd numbers in an array
def count_even_odd(arr):
    even_count = 0
    odd_count = 0
    for num in arr:
        if num % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    return even_count, odd_count
array = [1, 2, 3, 4, 5, 6, 7, 8, 9]
even_count, odd_count = count_even_odd(array)
print("Array:", array)
print("Number of even numbers:", even_count)
print("Number of odd numbers:", odd_count)



#16. Write a function to get the difference of largest and smallest value
def get_difference_largest_smallest(a):
    if not a:
        return "Array is empty"
    b = min(a)
    c = max(a)
    return c - b
array = [10, 5, 3, 8, 12]
difference = get_difference_largest_smallest(array)
print("Array:", array)
print("Difference between largest and smallest values:", difference)



#17. Write a method to verify if the array contains two specified elements(12,23)
def contains_12_23(a):
    return 12 in a and 23 in a
array1 = [1, 12, 4,23, 5]
array2 = [5, 9, 10, 12]
print("Array 1 contains both 12 and 23:", contains_12_23(array1))
print("Array 2 contains both 12 and 23:", contains_12_23(array2))



#18. Write a program to remove the duplicate elements and return the new array
def remove_duplicates(a):
    if not a:
        return a
    a.sort()
    index = 1
    for i in range(1, len(a)):
        if a[i] != a[i - 1]:
            a[index] = a[i]
            index += 1
    return a[:index]
b = [3, 1, 2, 2, 1, 4, 5, 4]
c = remove_duplicates(b)
print("Original Array:", b)
print("Array with Duplicates Removed:","new array", c)