#1. Write a program to read text file
a=open("text.txt","w")
a.write("welcome to my world")
a.close()
print(a)
a=open("text.txt","r")
print(a.read())


#