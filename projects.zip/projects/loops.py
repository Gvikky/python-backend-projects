#Write a program to print “Bright IT Career” ten times using for loop
count = 0
while count < 10:
    print("Bright IT Career")
    count += 1



#Program to equal operator and not equal operators
def check_the_number_is_equal_or_not(num1, num2):
    if num1 == num2:
        print("The numbers are equal.")
    else:
        print("The numbers are not equal.")
check_the_number_is_equal_or_not(10, 10)
check_the_number_is_equal_or_not(20, 10)



#program to print the odd and even numbers
def print_odd_and_even_numbers(start,end):
    print("even numbers")
    for i in range(start,end+1):
        if i%2==0:
            print(i)
    print("odd numbers")
    for i in range(start,end+1):
        if i%2!=0:
            print(i)

print_odd_and_even_numbers(1,20)



#program to print largest number among three numbers.
n1 = 43
n2 = 56
n3 = 28

if n1 > n2 and n1>n3:
    print("is larger number",n1)
elif n2 > n1 and n2>n3:
    print(n2,"is larger number")
elif n3 > n1 and n3>n2:
    print(n3,"is larger number")
else:
    print("please check the code")



#program to print even number between 10 and 20 using while
a=10
while a<=20:
    if a%2==0:
        print(a)
    a+=1
print("the even number between 10 and 20 is:")


#program to print 1 to 10 using the do-while loop statement.
a=1
print("the number from 1 to 10 using while is")
while True:
    print(a)
    a+=1
    if a>10:
        break


#program to find Armstrong number or not
a=153
b=str(a)
c=len(b)
d=sum(int(digit)**c for digit in b)
if d==a:
    print(d,"is a armstrong number")
else:
    print(d,"is not a armstrong number")


#program to find the prime or not.
a=int(input("enter the number"))
b=int(a/2)+1
for i in range(2,b):
    c=a%i
    if c==0:
        print(a,"is a not prime number")
        break
else:
    print(a,"is a prime number")


#program to palindrome or not.
a=int(input("enter the number"))
b=a
r=0
while a>0:
    d=a%10
    r=r*10+d
    a=a//10
if b==r:
    print("the number is palindrome")
else:
    print("the number is not a palindrome")



#check whether a number is EVEN or ODD using switch(if,else)
a=int(input("enter the number"))
b=a%2
if b==0:
    print(a,"is a even number")
else:
    print(a,"is a odd number")
