#1. Different ways creating a string
single_quote_string='welcome to my world'
double_quote_string="welcome to my world"
triple_quote_string='''welcome to my world'''


#2. Concatenating two strings using + operator
a="welcome"+" to "
b="my world"
print(a+b)



#3. Finding the length of the string
a="python is a programming language"
print(len(a))



#4. Extract a string using Substring
a="python is the fastest growing programming language"
b=a[0:7]
print(b)



#5. Searching in strings using index()
a="python is the fastest growing programming language"
b=a.index("the")
print(b)



#7. Comparing strings
a = "welcome"
b = "welcome"
if a == b:
    print("Strings are equal")
else:
    print("Strings are not equal")



#8. startsWith(), endsWith() and compareTo()
a="welcome to my world"
if a.startswith("welcome"):
    print("the text starts with 'welcome'")
else:
    print("the text does not startswith 'welcome'")

#using endswith()
a="welcome to my world"
if a.endswith("world"):
    print("the text endswith 'world'")
else:
    print("the text does not endswith 'world'")

#using compareto
a="welcome to my world"
if a.endswith("world"):
    print("True")
else:
    print("False")



#9. Trimming strings with strip()
a=" welcome homes  "
b=a.strip()
print(b)



#10. Replacing characters in strings with replace()
a=" welc ome,   homes  "
b=a.replace(" ","")
print(b)



#11. Splitting strings with split()
a=" welcome to my home  "
b=a.split()
print(b)



#12. Converting integer objects to Strings
a = 123
b = str(a)
print(b)


#13. Converting to uppercase and lowercase
#upper case
a="welcome"
b=a.upper()
print(b)

#lower case
a="WELCOME"
b=a.lower()
print(b)