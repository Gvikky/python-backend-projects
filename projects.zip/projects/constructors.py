'''1  Write a class with a default constructor, one argument constructor and two argument
constructors. Instantiate the class to call all the constructors of that class from a main
class'''

class Example:
    def __init__(self, arg1=None, arg2=None):
        if arg1 is not None and arg2 is not None:
            self.arg1 = arg1
            self.arg2 = arg2
            print("Two Argument Constructor:", self.arg1, self.arg2)
        elif arg1 is not None:
            self.arg1 = arg1
            print("One Argument Constructor:", self.arg1)
        else:
            print("Default Constructor")


class Main:
    def __init__(self):

        obj_default = Example()

        obj_one_arg = Example("Hello")

        obj_two_arg = Example("Hi", "World")


Main()



'''Call the constructors(both default and argument constructors) of super class from a child 
class'''

class SuperClass:
    def __init__(self, *args, **kwargs):
        if args:
            if len(args) == 1:
                self.arg1 = args[0]
                print("SuperClass One Argument Constructor:", self.arg1)
        else:
            print("SuperClass Default Constructor")


class SubClass(SuperClass):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


obj_default_subclass = SubClass()
obj_one_arg_subclass = SubClass("Hello")



#3. Apply private, public, protected and default access modifiers to the constructor
#public
class MyClass:
    def __init__(self):
        pass

#private
class MyClass:
    def __init__(self):
        self._private_variable = 10

    def _private_method(self):
        pass

#protected
class MyClass:
    def __init__(self):
        self.__protected_variable = 20

    def __protected_method(self):
        pass





#4. Write a program which illustrates the concept of attributes of a constructor.
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display_info(self):
        print(f"Name: {self.name}, Age: {self.age}")


person1 = Person("Alice", 30)
person2 = Person("Bob", 25)

person1.display_info()
person2.display_info()