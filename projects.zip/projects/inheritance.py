'''A, B and C are classes
A is a super class. B is a sub class of A. C is a sub class of B.
Create three methods in each class, 2 methods are specific to each class and third
method (override method) should be in all three Classes A, B and C
Create a class with main method. Create an object for each class A, B and C in main
method and call every method of each class using its own object/instance.
Call an overridden method with super class reference to B and C class’s objects
Runtime Polymorphism with Data Members/Instance variables, Repeat the above
process only for data members'''


class a:
    def speed(self):
        print("120km/hr")
    def name(self):
        print("jaguar")
    def cost(self):
        print("30 lakhs")
    def overridden_method(self):
        print("Overridden method in class a")
class b(a):
    def speed(self):
        print("150km/hr")
    def name(self):
        print("yamaha r15")
    def cost(self):
        print("2 lakhs")
    def overridden_method(self):
        print("Overridden method in class b")
class c(b):
    def speed(self):
        print("200km/hr")
    def name(self):
        print("ford")
    def cost(self):
        print("50 lakhs")
    def overridden_method(self):
        print("Overridden method in class c")

class Main:
    def main(self):
        A = a()
        B = b()
        C = c()

        A.name()
        A.speed()
        A.cost()
        A.overridden_method()

        B.name()
        B.speed()
        B.cost()
        B.overridden_method()

        C.name()
        C.speed()
        C.cost()
        C.overridden_method()

        super_ref_B = super(b, C)
        super_ref_C = super(c, C)
        super_ref_B.overridden_method()
        super_ref_C.overridden_method()

main_obj = Main()
main_obj.main()