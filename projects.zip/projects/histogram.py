def mean(x:list[float]):
    return sum(x)/len(x)
mean(x=101)