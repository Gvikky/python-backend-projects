from one import Class1
from two import class2
def main():
    obj1=Class1(10)
    obj1.method1()
    obj2 = class2("hello")
    obj2.method2()

if __name__=="__main__":
    main()