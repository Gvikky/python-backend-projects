class Class1:
    def __init__(self, value):
        self.value = value

    def method1(self):
      print(f"method called with value",self.value)
