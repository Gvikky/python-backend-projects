class class2:
    def __init__(self,text):
        self.text=text
    def method2(self):
        print(f"method called with text", self.text)
