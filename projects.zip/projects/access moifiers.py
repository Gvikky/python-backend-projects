'''1. Create a class with PRIVATE fields, private method and a main method. Print the fields
in main method. Call the private method in main method.
Create a sub class and try to access the private fields and methods from sub class.'''


class a:
    def __init__(self):
        self._private_field = 10

    def _private_method(self):
        print("This is a private method")

    def print__private_field(self):
        print("Private Field:", self._private_field)
        self._private_method()


class b(a):
    def access_private(self):
        print("Trying to access private field from subclass:", self._private_field)
        self._private_method()


def main():
    obj = a()
    obj.print__private_field()

    sub_obj = b()
    sub_obj.access_private()


if __name__ == "__main__":
    main()



'''2. Create a class with PROTECTED fields and methods. Access these fields and methods 
from any other class in the same package. 
Also, Access the PROTECTED fields and methods from child class located in a different 
package
Access the PROTECTED fields and methods from any class in different package'''


class a:
    def __init__(self):
        self._protected_field = 10

    def print__protected_field(self):
        print("protected Field:", self._protected_field)
        self._protected_method()

    def _protected_method(self):
        return "This is a protected method"


class b(a):
    def access_private(self):
        print("Trying to access private field from subclass:", self._protected_field)
        self._protected_method()


def main():
    obj = a()
    obj.print__protected_field()

    sub_obj = b()
    sub_obj.access_private()


if __name__ == "__main__":
    main()



'''3. Create a class with PUBLIC fields and methods. 
Access the public methods and fields from any class in the same package or different 
package.'''

