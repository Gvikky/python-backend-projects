#code to print your name
a=("vikky")
print("your name is",a)


#code using single and multi line comments
a=10
b=20
'''to add two values we use arithmetic operator
 (+)symbol'''
print(a+b)


#declaring variable using integer
a=5
b=10
print(a+b)

#declaring variable using character
c='welcome'
d='to my world'
print(c+d)

#declaring variable boolean
e=10
f=20
g=(e>f)
print(g)

#declaring variable using float
h=16.7
i=3
j=h/i
print(j)
