#1. Write a program to generate Arithmetic Exception without exception handling
def perform_division(dividend, divisor):
    result = dividend / divisor
    return result

result = perform_division(10, 2)
print(result)




#2. Handle the Arithmetic exception using try-catch block
def perform_division(dividend, divisor):
    try:
        result = dividend / divisor
        return result
    except ZeroDivisionError as e:
        print("Error:", e)
        return None

result = perform_division(10, 0)
if result is not None:
    print("Result:", result)
else:
    print("Division by zero was attempted and handled.")





#3. Write a method which throws exception, Call that method in main class without try block
class CustomException:
    def raise_exception(self):
        raise RuntimeError("Custom exception raised!")


class MainClass:
    def call_method_with_try(self):
        custom_exception = CustomException()
        try:
            custom_exception.raise_exception()
        except RuntimeError as e:
            print("Caught an exception:", e)


main = MainClass()
main.call_method_with_try()





#4. Write a program with multiple catch blocks
def perform_operation(a, b):
    try:
        result = a / b
        return result
    except ZeroDivisionError:
        print("Division by zero error!")
    except TypeError:
        print("Type error occurred!")
    except Exception as e:
        print("An unexpected error occurred: " + str(e))
    else:
        print("Operation performed successfully.")
    finally:
        print("Execution completed.")


perform_operation(10, 0)
perform_operation(10, 'test')
perform_operation(10, 2)




#5. Write a program to throw exception with your own message
class CustomException(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message


def check_value(value):
    if value < 0:
        raise CustomException("Value cannot be negative!")


try:
    check_value(5)
    check_value(-3)
except CustomException as e:
    print("Caught CustomException:", e.message)





#6. Write a program to create your own exception
class MyCustomException(Exception):
    def __init__(self, message="This is a custom exception."):
        super().__init__(message)
        self.message = message

def validate_input(value):
    if value < 0:
        raise MyCustomException("Input value should be non-negative.")

try:
    validate_input(10)
    validate_input(-5)
except MyCustomException as e:
    print("Caught MyCustomException:", e.message)





#7. Write a program with finally block
def function():
    raise ValueError("this function intentially raises an exception")


try:
    function()
except ValueError as e:
    print(f"an exception occured", e)
finally:
    print("this code will always executed")




#8. Write a program to generate Arithmetic Exception
def division(a, b):
    try:
        if b == 0:
            raise ZeroDivisionError("Division by zero is not allowed")
        result = a / b
        return result
    except ZeroDivisionError as e:
        return f"Error: {e}"

print(division(10, 2))
print(division(5, 0))




#9. Write a program to generate FileNotFoundException
try:
    with open("any_file.txt", "r") as file:
        content = file.read()
    print(content)
except FileNotFoundError as e:
    print("File not found:", e)
